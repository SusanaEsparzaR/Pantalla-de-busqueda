<?php
   

    /*// kvstore API url
    $url = '35.167.62.109/storeutags/security/create_accountPOST';

    // Collection object
    $data = [
    'collection' => 'RapidAPI'
    ];

    // Initializes a new cURL session
    $curl = curl_init($url);

    // 1. Set the CURLOPT_RETURNTRANSFER option to true
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    // 2. Set the CURLOPT_POST option to true for POST request
    curl_setopt($curl, CURLOPT_POST, true);

    // 3. Set the request data as JSON using json_encode function
    curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));

    // 4. Set custom headers for RapidAPI Auth and Content-Type header
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
  'X-RapidAPI-Host: kvstore.p.rapidapi.com',
  'X-RapidAPI-Key: [Input your RapidAPI Key Here]',
  'Content-Type: application/json'
  ]);*/

  $ch = curl_init(); // Inicio el CURL
  curl_setopt($ch, CURLOPT_URL, "http://35.167.62.109/storeutags/security/create_account");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  print_r($ch);
  $res = curl_exec($ch); // Respuesta
  print_r($res);
  curl_close($ch); // Cierro el CURL

?>